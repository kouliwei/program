#ifndef USER_DISTANCE_H
#define USER_DISTANCE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "DSPTotal.h"



void distanceframe(void);
interrupt void DistanceIstr(void);


#ifdef __cplusplus
}
#endif
#endif
